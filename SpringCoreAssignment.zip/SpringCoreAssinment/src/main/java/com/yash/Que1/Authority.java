package com.yash.Que1;

public class Authority 
{
	String person;

	public String getPerson() {
		return person;
	}

	public void setPerson(String person) {
		this.person = person;
	}
	
	public void show()
	{
		System.out.println("This is : "+person);
	}
	
}
