package com.yash.Que1;

/*
 *  WAP in spring core to demonstrate role based object creation using factory method
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AuthorityTest 
{
	public static void main(String[] args) 
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que1/applicationContext.xml");
		
		Authority a1 = (Authority) objAC.getBean("admin");
		Authority a2 = (Authority) objAC.getBean("user");
		
		a1.show();
		a2.show();
	}	
}
