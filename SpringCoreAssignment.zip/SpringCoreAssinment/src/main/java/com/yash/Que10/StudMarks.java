package com.yash.Que10;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudMarks
{
   private Map<String,Integer> maps = new HashMap<String, Integer>();

    public Map<String, Integer> getMaps() {
        return maps;
    }

    public void setMaps(Map<String, Integer> maps) {
        this.maps = maps;
    }

    @Override
    public String toString() {
        return "Stud [maps=" + maps + "]";
    }

	public void show() {
	    System.out.println(maps);
	}
	
	public void check() 
	{
	    System.out.println("Hello \n");
	    List<String>names=maps.entrySet().stream()
	            .filter(e->e.getValue()>200)
	            .map(e->e.getKey())
	            .collect(Collectors.toList());
	    System.out.println("Student whose marks greater than 200:"+names);
	}
}
