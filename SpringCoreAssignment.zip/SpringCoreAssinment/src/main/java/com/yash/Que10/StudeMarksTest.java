package com.yash.Que10;

/*
 * WAP to inject student name and marks into spring bean and you have to use hashmap. Use
 * key as student name and marks as value. And sort all the data and print the records. For
 * example you can inject map in following way.
 *
 *	<map>
 *		<entry key-ref="sunil" value-ref="350"></entry>
 *		<entry key-ref="anil" value-ref="401"></entry>
 *  </map> 
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudeMarksTest 
{
	public static void main(String[] args) 
	{
		ApplicationContext obj = new ClassPathXmlApplicationContext("com/yash/Que10/applicationContext.xml");

	    StudMarks stu = (StudMarks) obj.getBean("checkStud");
	        stu.show();
	        stu.check();
	}
}
