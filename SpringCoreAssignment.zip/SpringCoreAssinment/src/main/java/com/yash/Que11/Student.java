package com.yash.Que11;

public class Student
{
	String stuName;
	int rollNo;
	String DOB;
	String className;
	String Section;
	Result res;
	
	public Student(String stuName, int rollNo, String dOB, String className, String section, Result res) {
		super();
		this.stuName = stuName;
		this.rollNo = rollNo;
		DOB = dOB;
		this.className = className;
		Section = section;
		this.res = res;
	}
}
