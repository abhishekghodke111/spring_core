package com.yash.Que11;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentResultTest 
{
	public static void main(String[] args) 
	{
		
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que11/applicationContext.xml");
		
		List<Student> slist = new ArrayList<Student>();
		Student s1 = (Student) objAC.getBean("que11b");
		Student s2 = (Student) objAC.getBean("que11d");

		slist.add(s1);
		slist.add(s2);
		for(Student s :slist) {
			System.out.println(s.stuName+" "+s.res.total_marks);
			
		}
		System.out.println("On the basis of total marks");
		List<Student> sortedlist = slist.stream().sorted((s1, s2) -> Double.compare(s1.res.total_marks, s2.res.total_marks)).toList();
		for (Student w : sortedlist) {
		System.out.println(w.res.total_marks);
	}
}
