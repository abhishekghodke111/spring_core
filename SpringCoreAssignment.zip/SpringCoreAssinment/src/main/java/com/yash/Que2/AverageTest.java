package com.yash.Que2;

/*
 *  WAP in spring core to read the data using post_construct annotated method by user and
 *  perform calculation of average of numbers.
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.Que2.Average;

public class AverageTest 
{
	public static void main(String[] args) 
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que2/applicationContext.xml");
		Average objA = (Average) objAC.getBean("avg");
		
		objA.avgTest();
	}
}
