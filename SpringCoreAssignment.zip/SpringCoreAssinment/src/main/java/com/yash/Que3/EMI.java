package com.yash.Que3;

public class EMI 
{
	public double principal, time_year, rate, emi;
	
	public double getPrincipal() {
		return principal;
	}


	public void setPrincipal(double principal) {
		this.principal = principal;
	}


	public double getTime_year() {
		return time_year;
	}


	public void setTime_year(double time_year) {
		this.time_year = time_year;
	}


	public double getRate() {
		return rate;
	}


	public void setRate(double rate) {
		this.rate = rate;
	}


	public double getEmi() {
		return emi;
	}


	public void setEmi(double emi) {
		this.emi = emi;
	}


	public void EMI_Cal()
	{
		rate = rate / (12*100);
		time_year = time_year * 12 ;
		
		emi = (principal * rate * Math.pow(1 + rate, time_year))/(Math.pow(1+rate, time_year)-1);
		System.out.println();
		System.out.println("Monthly emi is : "+emi);
		System.out.println("Annually emi is : "+emi * 12);
		System.out.println("Total EMI : "+time_year);
	}
}
