package com.yash.Que3;

/*
 *  WAP to print No of EMI for a given amount of loan for a given number of years or month.
 *  You have to fetch the interest rate from the xml file and loam amount and rate of interest is
 *  entered by you. 
 */

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.Que3.EMI;

public class EMITest 
{
	public static void main(String[] args) 
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que3/applicationContext.xml");
		
		EMI objE = (EMI) objAC.getBean("emi");
		
		Scanner sc  = new Scanner(System.in);
		
		System.out.print("Enter the pricipal amount : ");
		objE.principal= sc.nextDouble();
		
		System.out.print("Enter the rate of EMI : ");
		objE.rate = sc.nextDouble();
		
		System.out.print("Enter the time period for EMI : ");
		objE.time_year = sc.nextInt();
		
		objE.EMI_Cal();
	}
}
