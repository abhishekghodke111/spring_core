package com.yash.Que5;

import java.util.Arrays;

public class Maximum 
{
	int a[];

	public int[] getA() {
		return a;
	}

	public void setA(int[] a) {
		this.a = a;
	}
	
	public void max() 
	{
		int max = a[0];
		
		for(int i = 0 ; i < a.length ; i++)
		{
			if(a[i] > max)
				max = a [i];
		}
		System.out.println("Maximum from Array : "+max);
	}

	@Override
	public String toString() {
		return "Maximum [a=" + Arrays.toString(a) + "]";
	}
	
}
