package com.yash.Que5;

/*
 * WAP to inject n numbers to a bean and find out the maximum out of them using stream
 * operator
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MaximumTest 
{
	public static void main(String[] args)
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que5/applicationContext.xml");
		
		Maximum m = (Maximum) objAC.getBean("maxcheck");
		
		m.max();
		System.out.println(m.a);
	}
}
