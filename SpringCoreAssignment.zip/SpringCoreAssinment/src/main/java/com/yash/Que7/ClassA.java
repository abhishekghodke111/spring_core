package com.yash.Que7;

public class ClassA 
{
	int a[];

	public int[] getA() {
		return a;
	}

	public void setA(int[] a) {
		this.a = a;
	}
	
}
