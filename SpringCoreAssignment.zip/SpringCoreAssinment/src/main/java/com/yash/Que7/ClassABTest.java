package com.yash.Que7;

/*
 * WAP to merge two Array from two different class. Two array will get values from the xml file
 * and now find maximum out of the merge array
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClassABTest 
{
	public static void main(String[] args)
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que7/applicationContext.xml");
		
		ClassA C1 = (ClassA) objAC.getBean("maxcheck1");
		ClassB C2 = (ClassB) objAC.getBean("maxcheck2");
		
		int c [] = new int[C1.a.length + C2.b.length];
		int position = 0 ;
		
		for(int element : C1.a)
		{
			c[position] = element;
			position++;
		}
		
		for(int element : C2.b)
		{
			c[position] = element;
			position++;
		}
		
		int max = c[0];
		for(int i = 0 ; i < c.length ; i++)
		{
			if(c[i]>max)
				max = c[i];
		}
		
		System.out.println("The maximum element from two array : "+max);
	}
}
