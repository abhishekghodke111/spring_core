package com.yash.Que7;

public class ClassB 
{
	int b [];

	public int[] getB() {
		return b;
	}

	public void setB(int[] b) {
		this.b = b;
	}

}
