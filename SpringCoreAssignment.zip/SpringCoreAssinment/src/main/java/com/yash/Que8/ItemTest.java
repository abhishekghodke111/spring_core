package com.yash.Que8;

/*
 * WAP inject list of item to bean and after this arrange all of the, item name in ascending and
 * descending order. Also remove any duplicate name of item if present.
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ItemTest 
{
	public static void main(String[] args) 
	{
		ApplicationContext objAC = new ClassPathXmlApplicationContext("com/yash/Que8/applicationContext.xml");
		
		Item I=(Item) objAC.getBean("item");
		I.show();
		System.out.println();
		
		I.Ascending();
		System.out.println();
		
		I.Descending();
		System.out.println();
		
		I.RemoveDuplicate();
	}
}
