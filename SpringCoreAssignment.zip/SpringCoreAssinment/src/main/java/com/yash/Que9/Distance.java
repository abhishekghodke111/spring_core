package com.yash.Que9;

public class Distance 
{
	String distance;
	
    public String getDistance() {
        return distance;
    }
    public void setDistance(String distance) {
        this.distance = distance;
    }
    
}
